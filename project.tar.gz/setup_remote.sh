#!/bin/bash
set -e

# --- System Setup ---
echo "Checking Docker installation..."
# Always try to install/fix Docker on Alinux 3
echo "Configuring Aliyun Docker mirror..."

# 1. Remove conflicting packages (podman, old docker)
yum remove -y docker \
              docker-client \
              docker-client-latest \
              docker-common \
              docker-latest \
              docker-latest-logrotate \
              docker-logrotate \
              docker-engine \
              podman \
              runc || true

# 2. Install utilities
yum install -y yum-utils

# 3. Add Aliyun Docker CE repo
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

# 4. Install Docker CE
yum install -y docker-ce docker-ce-cli containerd.io

# 5. Configure Aliyun Docker Registry Mirror (CRITICAL for China server)
echo "Configuring Docker Registry Mirror..."
mkdir -p /etc/docker
# Use simple echo to avoid heredoc nesting issues
echo '{ "registry-mirrors": ["https://registry.cn-hangzhou.aliyuncs.com"] }' > /etc/docker/daemon.json
systemctl daemon-reload

# 6. Start Docker
systemctl restart docker
systemctl enable docker

# --- Project Setup ---
echo "Preparing project directory..."
mkdir -p /root/xhs-scraper
cd /root/xhs-scraper

echo "Extracting files..."
if [ -f "project.tar.gz" ]; then
    tar -xzf project.tar.gz
    rm project.tar.gz
else
    echo "⚠️ project.tar.gz not found in current dir, assuming already extracted or moved."
fi

# --- Docker Build & Run ---
echo "🔨 Building Docker image (this may take a few minutes)..."
docker build -t xhs-app .

echo "🔄 Restarting container..."
# Stop and remove existing container if any
docker stop xhs-container 2>/dev/null || true
docker rm xhs-container 2>/dev/null || true

# Run new container
docker run -d \
    -p 5007:5007 \
    --name xhs-container \
    --restart unless-stopped \
    xhs-app

echo "⏳ Waiting for container to initialize..."
sleep 10

echo "🔍 Checking container status..."
if [ "$(docker inspect -f '{{.State.Running}}' xhs-container)" = "true" ]; then
    echo "✅ Container is RUNNING!"
else
    echo "❌ Container has STOPPED/CRASHED!"
fi

echo "📋 Container Logs (Last 50 lines):"
echo "==================================="
docker logs --tail 50 xhs-container
echo "==================================="

echo "✅ Remote setup finished successfully!"
