#!/bin/bash

# Configuration
SERVER_IP="123.56.83.213"
USER="root"
REMOTE_DIR="/root/xhs-scraper"

echo "========================================"
echo "🚀 Starting Deployment to Alibaba Cloud"
echo "Target: $USER@$SERVER_IP"
echo "========================================"

# 1. Clean up old artifacts
rm -f project.tar.gz

# 2. Compress project files locally
echo "📦 Packing project files..."
# Exclude heavy/unnecessary folders
tar --exclude='node_modules' \
    --exclude='.git' \
    --exclude='.venv' \
    --exclude='datas' \
    --exclude='__pycache__' \
    --exclude='*.xlsx' \
    --exclude='.DS_Store' \
    --exclude='login_qrcode.png' \
    -czf project.tar.gz .

# 3. Upload to server
echo "📤 Uploading files to server..."
echo "⚠️  Please enter your server password if prompted (for SCP):"
# Create remote dir first
ssh $USER@$SERVER_IP "mkdir -p $REMOTE_DIR"
# Upload tarball and setup script
scp project.tar.gz setup_remote.sh $USER@$SERVER_IP:$REMOTE_DIR/

# 4. Remote execution
echo "🔧 Executing setup script on server..."
echo "⚠️  Please enter your server password if prompted (for SSH):"
ssh $USER@$SERVER_IP "cd $REMOTE_DIR && bash setup_remote.sh"

# 5. Cleanup local file
rm -f project.tar.gz

echo "========================================"
echo "🎉 Deployment Process Finished!"
echo "🌍 You can access your app at: http://$SERVER_IP:5007"
echo "⚠️  IMPORTANT: Make sure to open Port 5007 in your Alibaba Cloud Security Group (安全组)!"
echo "========================================"
